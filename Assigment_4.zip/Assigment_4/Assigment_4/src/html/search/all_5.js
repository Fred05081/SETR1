var searchData=
[
  ['len_5fdados_17',['len_dados',['../main_8c.html#a6f1906b9c40734b4c243278466d4ec0b',1,'main.c']]]
];
