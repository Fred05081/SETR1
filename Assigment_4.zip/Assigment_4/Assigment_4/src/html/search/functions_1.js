var searchData=
[
  ['k_5fthread_5fstack_5fdefine_43',['K_THREAD_STACK_DEFINE',['../main_8c.html#aa25f5f9092ccf13998f3cb9e9e1d10a6',1,'K_THREAD_STACK_DEFINE(thread_A_stack, STACK_SIZE):&#160;main.c'],['../main_8c.html#a8318aa1ed5939244957a68387085ddec',1,'K_THREAD_STACK_DEFINE(thread_B_stack, STACK_SIZE):&#160;main.c'],['../main_8c.html#a331fd55d9b95c3e662a4148fbc522271',1,'K_THREAD_STACK_DEFINE(thread_C_stack, STACK_SIZE):&#160;main.c']]]
];
