var searchData=
[
  ['bc_9',['bc',['../main_8c.html#a97102b52a1cf13a343a1a414bc865cde',1,'main.c']]],
  ['boardled1_10',['BOARDLED1',['../main_8c.html#ad66f6c0ce6fd44d24653df422e7a8c92',1,'main.c']]],
  ['buffer_5fsize_11',['BUFFER_SIZE',['../main_8c.html#a6b20d41d6252e9871430c242cb1a56e7',1,'main.c']]],
  ['bug_20list_12',['Bug List',['../bug.html',1,'']]]
];
