var searchData=
[
  ['sem_5fab_22',['sem_ab',['../main_8c.html#a82e13125c2f279157fcf738219ff21ba',1,'main.c']]],
  ['sem_5fbc_23',['sem_bc',['../main_8c.html#addc907d18e7e98a64a832ac1c7be5ad1',1,'main.c']]],
  ['semaphore_2eh_24',['semaphore.h',['../semaphore_8h.html',1,'']]],
  ['stack_5fsize_25',['STACK_SIZE',['../main_8c.html#a6423a880df59733d2d9b509c7718d3a9',1,'main.c']]]
];
