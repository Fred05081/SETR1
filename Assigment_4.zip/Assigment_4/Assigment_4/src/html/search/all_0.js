var searchData=
[
  ['ab_0',['ab',['../main_8c.html#a2c9b173c6ea51db9d371f2d06fd8582f',1,'main.c']]],
  ['adc_5facquisition_5ftime_1',['ADC_ACQUISITION_TIME',['../main_8c.html#aeb8de5967ac4465f35317d818eeb129b',1,'main.c']]],
  ['adc_5fchannel_5fid_2',['ADC_CHANNEL_ID',['../main_8c.html#a8bfca74ee546715af6682194ea92286a',1,'main.c']]],
  ['adc_5fchannel_5finput_3',['ADC_CHANNEL_INPUT',['../main_8c.html#a5508ef7e762284248c2e87e16865522e',1,'main.c']]],
  ['adc_5fdev_4',['adc_dev',['../main_8c.html#a445f79326d40128ece59a749adff6894',1,'main.c']]],
  ['adc_5fgain_5',['ADC_GAIN',['../main_8c.html#a2bbc7e1578f01928d36ef7fa94ac4905',1,'main.c']]],
  ['adc_5fnid_6',['ADC_NID',['../main_8c.html#a667158ed9af1b72bf062e54bda71dd4f',1,'main.c']]],
  ['adc_5freference_7',['ADC_REFERENCE',['../main_8c.html#a317868c528ebe27fbca094a8bc2d910c',1,'main.c']]],
  ['adc_5fresolution_8',['ADC_RESOLUTION',['../main_8c.html#a00978ca9e8220475258dcbbbb7d29129',1,'main.c']]]
];
