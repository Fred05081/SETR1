var searchData=
[
  ['ab_48',['ab',['../main_8c.html#a2c9b173c6ea51db9d371f2d06fd8582f',1,'main.c']]],
  ['adc_5fdev_49',['adc_dev',['../main_8c.html#a445f79326d40128ece59a749adff6894',1,'main.c']]]
];
