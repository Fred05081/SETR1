var searchData=
[
  ['gpio0_5fnid_15',['GPIO0_NID',['../main_8c.html#a4c0e6f34369bef1deb3a9efae6ac14fb',1,'main.c']]]
];
